# Daily Cafe Website - Part 2

This project is a 5-page responsive website for the Daily Cafe in East London. For Part 2, the website has been significantly refactored from its original static HTML structure into a modern, standards-compliant, and fully responsive interface utilizing external CSS3.

## Student Information
* **Name:** RETHABILE EDEN LENONG
* **Student Number:** ST10528266
* **Institution:** Rosebank College

## Changelog: Part 2 Improvements
The codebase underwent a complete refactoring to transition from static, table-based HTML to a modern, responsive architecture. Key improvements include:

1. **Semantic HTML5 Migration:** Removed all `<table>` structural layouts in favor of `<header>`, `<main>`, `<section>`, and `<footer>` for better accessibility and SEO.
2. **External CSS Integration:** Stripped all inline `style="..."` attributes, centralizing all presentation in `css/style.css` for maintainability.
3. **Responsive Navigation:** Replaced float-based headers with CSS Flexbox for fluid, aligned navigation on all devices.
4. **CSS Grid Implementation:** Restructured the `menu.html` product layout into a CSS Grid to ensure a responsive, multi-column display.
5. **Global Typography Scale:** Implemented relative units (`rem`/`em`) to ensure consistent, scalable readability across all platforms.
6. **Mobile-Responsive Media:** Removed hardcoded image/iframe widths and applied `max-width: 100%;` to ensure content scales gracefully on mobile.
7. **Form UI Enhancements:** Added CSS pseudo-classes (`:hover`, `:focus`) to enquiry and contact forms, significantly improving user interaction feedback.
8. **Universal CSS Reset:** Applied a global `box-sizing: border-box` reset to eliminate browser-default spacing issues.
9. **Deprecated Tag Removal:** Eliminated legacy tags such as `<center>`, `bgcolor`, and `<br>` spacers, delegating all design control to the external stylesheet.
10. **Standardized Component Design:** Synchronized footer and header styling across all five pages, creating a cohesive, professional brand identity.

LASLTY I PLAN TO USE CSS to style my website
i will use color palette that are minmal and sleek 
## Responsive Design Testing
The layout has been verified for responsiveness across desktop, tablet, and mobile breakpoints.

### Desktop View
![Desktop View](images/desktop-view.png) ![alt text](desktop-view-1.png)

### Tablet View
![Tablet View](images/tablet-view.png) ![alt text](tablet-view.png)

### Mobile View
![Mobile View](images/mobile-view.png)   ![alt text](mobile-view.png)

## Technologies Used
* **HTML5:** Semantic structural design.
* **CSS3:** Flexbox, CSS Grid, Media Queries.
* **Git/GitHub:** Version control and repository hosting.

Canva, 2026. Colour theory and design basics. [online] Available at: https://www.canva.com [Accessed 29 May 2026].

GitHub, 2026. GitHub. [online] Available at: https://github.com [Accessed 29 May 2026].

Google LLC, 2026. Web design basics & flexbox/grid documentation. [online] Available at: https://developers.google.com [Accessed 29 May 2026].

HubSpot, 2026. Website design and user experience principles. [online] Available at: https://www.hubspot.com [Accessed 29 May 2026].

Microsoft, 2026. Visual Studio Code. [software] Available at: https://code.visualstudio.com [Accessed 29 May 2026].